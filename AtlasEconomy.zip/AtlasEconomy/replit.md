# Atlas Air Pilot Dashboard - Replit Configuration

## Overview

Atlas Air Pilot Dashboard is a Flask-based web application that simulates a pilot's dashboard and shopping system. The application allows pilots to view their profile information, check their balance, and purchase aircraft access through an integrated shop system.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Template Engine**: Jinja2 (Flask's default)
- **CSS Framework**: Bootstrap 5 with dark theme
- **Icons**: Font Awesome 6.4.0
- **JavaScript**: Vanilla JavaScript with Bootstrap components
- **Responsive Design**: Mobile-first approach using Bootstrap grid system

### Backend Architecture
- **Framework**: Flask (Python web framework)
- **Session Management**: Flask sessions with server-side storage
- **Middleware**: ProxyFix for handling proxy headers
- **Configuration**: Environment-based configuration for secrets

### Data Storage
- **Database**: PostgreSQL for persistent pilot data storage
- **Authentication**: Secure password hashing with Werkzeug
- **Static Data**: Shop items stored as Python dictionaries in application code
- **User Data**: Pilot profiles, balance, aircraft fleet, and statistics in database

## Key Components

### Application Structure
- `app.py` - Main Flask application with routes, database models, and authentication
- `main.py` - Application entry point and server configuration
- `templates/` - Jinja2 HTML templates for UI rendering
- `static/` - CSS, JavaScript, and asset files

### Core Features
1. **Authentication System** - Username/password login with PostgreSQL database
2. **Pilot Dashboard** - Personalized dashboard showing pilot statistics and fleet
3. **Aviation Shop** - Aircraft purchase system with category organization
4. **Flight Tracking System** - Real-time flight tracking with stopwatch functionality
5. **Flight Logs** - GTI flight logging with detailed tracking and duration recording
6. **Discord Integration** - Two-way API sync between Discord bot and dashboard
7. **Database Management** - Persistent pilot data with PostgreSQL
8. **Purchase System** - Item buying with balance validation and fleet tracking

### Template System
- `base.html` - Master template with navigation, authentication-aware header
- `index.html` - Landing page with login button and fleet showcase
- `login.html` - Authentication form with demo credentials
- `dashboard.html` - Authenticated pilot dashboard with statistics and fleet
- `shop.html` - Shop interface for aircraft purchases (authenticated)
- `flights.html` - Available flights listing (authenticated)
- `flight_logs.html` - Flight history and logging interface
- `add_flight_log.html` - Flight logging form with GTI format validation
- `flight_tracker.html` - Real-time flight tracking with stopwatch interface

## Data Flow

1. **Landing Page**: Unauthenticated users see homepage with login button
2. **Authentication**: Users login with username/password (demo: pilot001/password123)
3. **Dashboard Access**: Authenticated users redirected to personalized dashboard
4. **Shop Browsing**: Protected shop route displays aircraft with ownership status
5. **Purchase Flow**: Purchase route validates balance and updates database
6. **State Persistence**: All changes saved to PostgreSQL database

## External Dependencies

### CDN Resources
- Bootstrap 5 CSS (Replit agent dark theme)
- Font Awesome 6.4.0 icons
- Bootstrap JavaScript components

### Python Packages
- Flask - Web framework
- Werkzeug - WSGI utilities and middleware

## Deployment Strategy

### Current Setup
- **Host**: 0.0.0.0 (all interfaces)
- **Port**: 5000
- **Debug Mode**: Enabled for development
- **Proxy Support**: ProxyFix middleware for deployment behind proxies

### Environment Variables
- `SESSION_SECRET` - Flask session encryption key (falls back to development default)

### Scalability Considerations
- No persistent database (sessions are temporary)
- Static shop data (no dynamic inventory management)
- Single-instance deployment (sessions not shared across instances)

## Development Notes

### Missing Components
The application currently uses in-memory session storage and static data. For production use, consider adding:
- Database integration (SQLite, PostgreSQL, etc.)
- User authentication system
- Persistent data storage
- API endpoints for mobile/external access

### Security Considerations
- Session secret should be set via environment variable in production
- No authentication/authorization beyond session management
- Purchase validation relies on client-side JavaScript (should be server-side)

### Extension Points
- Database schema could be added for pilots, aircraft, and purchases
- API routes could be added for REST/GraphQL access
- Authentication system could be integrated
- Real-time features could be added with WebSockets