# Atlas Air Pilot Dashboard

A comprehensive Flask web application for Atlas Air's Discord bot economy system where pilots can earn and spend virtual currency on aviation-related items.

## 🚁 Features

### Core Systems
- **Pilot Authentication**: Username/password login with PostgreSQL database
- **Flight Logging**: GTI flight number format with detailed tracking
- **Real-time Flight Tracking**: Stopwatch functionality with pause/resume/end controls
- **Shop System**: Aircraft and equipment purchases with balance validation
- **Statistics Tracking**: Automatic updates for flight hours, completed flights, and cargo delivered
- **Discord Integration**: Two-way API sync for /stats command

### Flight Management
- **Flight Routes**: Continental, Asian, and Cargo Hub categories
- **GTI Flight Numbers**: Professional aviation branding (GTI_2001, etc.)
- **Flight Rewards**: $50 per completed flight + statistics updates
- **Flight History**: Complete logging system with duration tracking

### Shop & Economy
- **Aircraft Fleet**: Boeing 747-400F, 767-300F, 747-8F, 777-F
- **Equipment & Upgrades**: Specialized cargo handling equipment
- **Purchase System**: Balance validation and confirmation modals
- **Ownership Tracking**: Visual indicators for owned/available/locked items

## 🛠️ Technical Stack

- **Backend**: Flask (Python)
- **Database**: PostgreSQL with SQLAlchemy ORM
- **Frontend**: Tailwind CSS with responsive design
- **Authentication**: Werkzeug password hashing
- **Session Management**: Server-side storage
- **Icons**: Font Awesome 6.4.0

## 📱 Mobile Access

The application is fully responsive and works perfectly on mobile devices:
- Access via any mobile browser
- Responsive Tailwind CSS design
- "Add to Home Screen" capability
- All desktop features available on mobile

## 🚀 Setup & Installation

### Prerequisites
- Python 3.11+
- PostgreSQL database
- Environment variables configured

### Environment Variables
```bash
DATABASE_URL=postgresql://username:password@host:port/database
SESSION_SECRET=your-secure-secret-key
```

### Installation
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

2. Run the application:
   ```bash
   python main.py
   ```
   Or using Gunicorn:
   ```bash
   gunicorn --bind 0.0.0.0:5000 --reload main:app
   ```

## 📊 Database Models

### Pilot Model
```python
class Pilot(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    callsign = db.Column(db.String(20), nullable=False)
    rank = db.Column(db.String(50), default='First Officer')
    balance = db.Column(db.Integer, default=25000)
    hours = db.Column(db.Integer, default=0)
    completed_flights = db.Column(db.Integer, default=0)
    aircraft_owned = db.Column(db.Text, default='')
    cargo_delivered = db.Column(db.Integer, default=0)
    status = db.Column(db.String(20), default='Active')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
```

### Flight Log Model
```python
class FlightLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    pilot_id = db.Column(db.Integer, db.ForeignKey('pilot.id'), nullable=False)
    flight_number = db.Column(db.String(20), nullable=False)  # GTI_1234 format
    aircraft_type = db.Column(db.String(50), nullable=False)
    departure_airport = db.Column(db.String(10), nullable=False)
    arrival_airport = db.Column(db.String(10), nullable=False)
    cargo_type = db.Column(db.String(100), nullable=False)
    departure_time = db.Column(db.DateTime, nullable=False)
    flight_duration = db.Column(db.Integer, default=0)  # seconds
    status = db.Column(db.String(20), default='In Progress')
```

## 🛣️ Routes & Pages

### Authentication
- `/` - Landing page with login
- `/login` - Pilot authentication
- `/logout` - Session termination

### Dashboard & Navigation
- `/dashboard` - Main pilot dashboard with statistics
- `/flights` - Available flight routes (GTI format)
- `/shop` - Aircraft and equipment store

### Flight Operations
- `/add_flight_log` - Flight logging form
- `/flight_logs` - Flight history
- `/flight_tracker/<int:flight_id>` - Real-time flight tracking
- `/pause_flight/<int:flight_id>` - Pause flight timer
- `/resume_flight/<int:flight_id>` - Resume flight timer
- `/end_flight/<int:flight_id>` - Complete flight with rewards

### Commerce
- `/purchase` - Item purchase processing

## 🎯 Discord Integration

The application includes comprehensive Discord API integration:
- `/stats` command endpoint for Discord bot
- Real-time pilot statistics synchronization
- Automatic updates when flights are completed
- See `DISCORD_API_INTEGRATION.md` for full documentation

## 🏗️ File Structure

```
├── app.py                    # Main Flask application
├── main.py                   # Application entry point
├── templates/
│   ├── base.html            # Master template
│   ├── index.html           # Landing page
│   ├── login.html           # Authentication
│   ├── dashboard.html       # Pilot dashboard
│   ├── flights.html         # Available flights
│   ├── shop.html            # Aircraft store
│   ├── flight_logs.html     # Flight history
│   ├── add_flight_log.html  # Flight logging
│   └── flight_tracker.html  # Real-time tracking
├── static/
│   ├── css/style.css        # Custom styles
│   └── js/main.js           # JavaScript functionality
└── DISCORD_API_INTEGRATION.md
```

## 🔧 Development

### Demo Account
- Username: `pilot001`
- Password: `password123`

### Key Features Implemented
✅ Complete flight workflow with rewards
✅ Professional shop interface with specifications
✅ GTI flight number branding throughout
✅ Real-time flight tracking with stopwatch
✅ Automatic pilot statistics updates
✅ Discord API integration ready
✅ Mobile-responsive design
✅ PostgreSQL database integration

## 📝 License

This project is developed for Atlas Air Cargo VA Discord economy system.