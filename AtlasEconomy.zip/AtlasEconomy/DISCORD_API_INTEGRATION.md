# Discord Bot API Integration Guide

## Overview

Your Atlas Air Cargo VA dashboard includes comprehensive Discord bot integration with flight tracking capabilities. The system supports real-time synchronization of pilot stats, flight hours, and GTI flight logs between your Discord bot and the web dashboard.

## Integration Methods

### 1. Dashboard to Discord Bot (Pull Data)

**Endpoint:** `/sync-discord/<discord_user_id>`

The dashboard can pull pilot data from your Discord bot API:

```python
# Your Discord bot should expose an API endpoint like:
# GET https://your-bot-api.com/pilot/{discord_user_id}

# Expected response format:
{
    "balance": 45000,
    "flight_hours": 234,
    "completed_flights": 47,
    "cargo_delivered": 1847,
    "rank": "Captain",
    "aircraft_owned": ["boeing_767", "boeing_777"]
}
```

### 2. Discord Bot to Dashboard (Push Data)

**Endpoint:** `POST /api/pilot/<pilot_id>/update`

Your Discord bot can push updates to the dashboard:

```python
import requests

# Update pilot data from Discord bot
def update_pilot_dashboard(pilot_id, data):
    url = f"https://your-dashboard-url.com/api/pilot/{pilot_id}/update"
    response = requests.post(url, json=data)
    return response.json()

# Example usage:
pilot_data = {
    "balance": 50000,
    "hours": 250,
    "completed_flights": 52,
    "cargo_delivered": 2100,
    "rank": "Captain",
    "aircraft_owned": ["boeing_767", "boeing_777", "boeing_747"]
}
result = update_pilot_dashboard(1, pilot_data)
```

### 3. Dashboard API (Get Pilot Data)

**Endpoint:** `GET /api/pilot/<pilot_id>`

Get current pilot data from the dashboard:

```python
import requests

def get_pilot_data(pilot_id):
    url = f"https://your-dashboard-url.com/api/pilot/{pilot_id}"
    response = requests.get(url)
    return response.json()

# Example response:
{
    "id": 1,
    "username": "pilot001",
    "name": "Captain John Smith",
    "callsign": "ATLAS001",
    "rank": "Captain",
    "balance": 45000,
    "hours": 234,
    "completed_flights": 47,
    "cargo_delivered": 1847,
    "aircraft_owned": ["boeing_767", "boeing_777"],
    "status": "Active",
    "created_at": "2025-01-18T18:44:00"
}
```

## Discord Bot Integration Examples

### Discord.py Bot Example with Stats Command Integration

```python
import discord
from discord.ext import commands
import requests
from flask import Flask, jsonify
import json

class AtlasAirCargo(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.dashboard_url = "https://your-dashboard-url.com"
        # Your pilot database (replace with your actual database)
        self.pilot_database = {}
    
    @commands.command(name='stats')
    async def stats_command(self, ctx):
        """Display pilot statistics (this is your existing /stats command)"""
        user_id = ctx.author.id
        
        # Get pilot data from your bot's database
        pilot_data = self.get_pilot_stats(user_id)
        
        if not pilot_data:
            await ctx.send("❌ No pilot data found for your account.")
            return
        
        # Create stats embed
        embed = discord.Embed(
            title=f"📊 Pilot Statistics - {ctx.author.display_name}",
            color=0x2563eb
        )
        embed.add_field(name="💰 Balance", value=f"${pilot_data['balance']:,}", inline=True)
        embed.add_field(name="🕒 Flight Hours", value=f"{pilot_data['flight_hours']} hours", inline=True)
        embed.add_field(name="✈️ Completed Flights", value=f"{pilot_data['completed_flights']}", inline=True)
        embed.add_field(name="📦 Cargo Delivered", value=f"{pilot_data['cargo_delivered']} tons", inline=True)
        embed.add_field(name="🏆 Rank", value=pilot_data['rank'], inline=True)
        embed.add_field(name="🛩️ Aircraft Owned", value=str(len(pilot_data['aircraft_owned'])), inline=True)
        
        # Add GTI flights if any
        if pilot_data.get('gti_flights'):
            recent_flights = pilot_data['gti_flights'][-5:]  # Last 5 flights
            flight_text = "\n".join([
                f"{flight['flight_number']} - {flight['aircraft']} ({flight['duration_hours']}h)"
                for flight in recent_flights
            ])
            embed.add_field(name="🛫 Recent GTI Flights", value=flight_text, inline=False)
        
        await ctx.send(embed=embed)
    
    @commands.command(name='sync')
    async def sync_stats(self, ctx):
        """Sync pilot stats to dashboard"""
        user_id = ctx.author.id
        
        # Get pilot data from your Discord bot database
        pilot_data = self.get_pilot_stats(user_id)
        
        if not pilot_data:
            await ctx.send("❌ No pilot data found to sync.")
            return
        
        # Update dashboard via API
        response = requests.post(
            f"{self.dashboard_url}/api/pilot/{pilot_data['pilot_id']}/update",
            json={
                "balance": pilot_data['balance'],
                "hours": pilot_data['flight_hours'],
                "completed_flights": pilot_data['completed_flights'],
                "cargo_delivered": pilot_data['cargo_delivered'],
                "rank": pilot_data['rank'],
                "aircraft_owned": pilot_data['aircraft_owned']
            }
        )
        
        if response.status_code == 200:
            await ctx.send("✅ Stats synced to dashboard!")
        else:
            await ctx.send("❌ Failed to sync stats")
    
    def get_pilot_stats(self, user_id):
        """Get pilot statistics from your database (implement your own logic)"""
        # Replace this with your actual database query
        # This is just an example structure
        return {
            "pilot_id": 1,  # Dashboard pilot ID
            "username": self.bot.get_user(user_id).display_name,
            "balance": 45000,
            "flight_hours": 234,
            "completed_flights": 47,
            "cargo_delivered": 1847,
            "rank": "Captain",
            "aircraft_owned": ["boeing_767", "boeing_777"],
            "gti_flights": [
                {
                    "flight_number": "GTI_1001",
                    "aircraft": "747-400F",
                    "route": "KJFK-EGLL",
                    "duration_hours": 8.5,
                    "date": "2025-01-18"
                }
            ]
        }
    
    @commands.command(name='dashboard')
    async def get_dashboard_link(self, ctx):
        """Get dashboard link with login info"""
        embed = discord.Embed(
            title="Atlas Air Cargo Dashboard",
            description="Access your pilot dashboard with flight tracking",
            color=0x2563eb
        )
        embed.add_field(
            name="Dashboard URL",
            value=f"{self.dashboard_url}/login",
            inline=False
        )
        embed.add_field(
            name="Features",
            value="• Real-time flight tracking with stopwatch\n• GTI flight logging system\n• Aircraft fleet management\n• Discord stats synchronization",
            inline=False
        )
        await ctx.send(embed=embed)

def setup(bot):
    bot.add_cog(AtlasAirCargo(bot))

# Optional: Create API endpoint for dashboard to pull data from your bot
app = Flask(__name__)

@app.route('/api/stats/<int:discord_user_id>')
def get_pilot_stats_api(discord_user_id):
    """API endpoint for dashboard to pull pilot stats"""
    # Get data from your bot's database
    cog = bot.get_cog('AtlasAirCargo')
    pilot_data = cog.get_pilot_stats(discord_user_id)
    
    if not pilot_data:
        return jsonify({"error": "Pilot not found"}), 404
    
    return jsonify(pilot_data)

if __name__ == "__main__":
    # Run both bot and API server
    import threading
    
    # Start Flask API in separate thread
    api_thread = threading.Thread(target=lambda: app.run(host='0.0.0.0', port=5001))
    api_thread.daemon = True
    api_thread.start()
    
    # Start Discord bot
    bot.run('YOUR_BOT_TOKEN')
```

### Node.js Bot Example

```javascript
const { Client, GatewayIntentBits } = require('discord.js');
const axios = require('axios');

const client = new Client({
    intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages]
});

const DASHBOARD_URL = 'https://your-dashboard-url.com';

client.on('messageCreate', async (message) => {
    if (message.content.startsWith('!sync')) {
        const userId = message.author.id;
        
        // Get pilot data from your bot database
        const pilotData = await getPilotData(userId);
        
        try {
            const response = await axios.post(
                `${DASHBOARD_URL}/api/pilot/${pilotData.pilotId}/update`,
                {
                    balance: pilotData.balance,
                    hours: pilotData.hours,
                    completed_flights: pilotData.flights,
                    cargo_delivered: pilotData.cargo,
                    rank: pilotData.rank,
                    aircraft_owned: pilotData.aircraft
                }
            );
            
            message.reply('✅ Stats synced to dashboard!');
        } catch (error) {
            message.reply('❌ Failed to sync stats');
            console.error(error);
        }
    }
});

client.login('YOUR_BOT_TOKEN');
```

## Setup Instructions

### 1. Update Discord Bot API URL

In `app.py`, update the Discord bot API URL:

```python
# Line 377 in app.py
discord_api_url = f"https://your-actual-bot-api.com/pilot/{discord_user_id}"
```

### 2. Authentication (Optional)

For production, add API key authentication:

```python
@app.route('/api/pilot/<int:pilot_id>/update', methods=['POST'])
def api_update_pilot(pilot_id):
    # Add API key check
    api_key = request.headers.get('X-API-Key')
    if api_key != 'your-secret-api-key':
        return {'error': 'Invalid API key'}, 401
    
    # ... rest of function
```

### 3. CORS (if needed)

If your Discord bot runs on a different domain:

```python
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # Allow all origins, or specify specific domains
```

## Data Mapping

| Discord Bot Field | Dashboard Field | Description |
|------------------|-----------------|-------------|
| balance | balance | Pilot's virtual currency |
| flight_hours | hours | Total flight hours |
| completed_flights | completed_flights | Number of flights completed |
| cargo_delivered | cargo_delivered | Total cargo delivered (tons) |
| rank | rank | Pilot rank/certification |
| aircraft_owned | aircraft_owned | List of owned aircraft |

## Testing

1. **Test Dashboard API:**
   ```bash
   curl -X GET "https://your-dashboard-url.com/api/pilot/1"
   ```

2. **Test Update API:**
   ```bash
   curl -X POST "https://your-dashboard-url.com/api/pilot/1/update" \
        -H "Content-Type: application/json" \
        -d '{"balance": 60000, "hours": 300}'
   ```

3. **Test Discord Sync:**
   - Login to dashboard
   - Click "Sync Discord Stats" button
   - Enter Discord User ID
   - Verify stats update

## Security Considerations

- Use HTTPS for all API communications
- Implement rate limiting on API endpoints
- Validate and sanitize all input data
- Use API keys for production environments
- Log all API requests for monitoring

## Troubleshooting

- **Connection Failed:** Check Discord bot API URL and network connectivity
- **Data Not Updating:** Verify API endpoint responses match expected format
- **Authentication Issues:** Ensure API keys are correctly configured
- **CORS Errors:** Add proper CORS headers for cross-domain requests